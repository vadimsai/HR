create
    definer = hrhr2@`%` procedure updateColumnStudent(IN studId int, IN nName varchar(255))
BEGIN
    update columnstudent set surname=nName where id=studId;
end;

