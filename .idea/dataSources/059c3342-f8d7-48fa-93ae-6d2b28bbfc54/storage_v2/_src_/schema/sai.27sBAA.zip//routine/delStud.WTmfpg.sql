create
    definer = hrhr2@`%` procedure delStud(IN studId int)
BEGIN
    delete from columnstudent  where id=studId;
end;

