create PROCEDURE getCoun_10(d in INTEGER, x out number)
    is

begin
    select count(*) into x from employees WHERE employee_id=d;

end getCoun_10;
/

