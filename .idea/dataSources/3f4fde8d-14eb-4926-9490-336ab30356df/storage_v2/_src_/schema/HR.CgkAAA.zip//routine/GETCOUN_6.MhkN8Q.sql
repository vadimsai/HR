create PROCEDURE getCoun_6(d in INTEGER)
    is
    a INTEGER;
begin
    select count(*) into a from employees WHERE employee_id=d;
    DBMS_OUTPUT.PUT_LINE(a);
end getCoun_6;
/

