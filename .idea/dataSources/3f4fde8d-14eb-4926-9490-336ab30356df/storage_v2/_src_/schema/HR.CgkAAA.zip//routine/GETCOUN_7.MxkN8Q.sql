create PROCEDURE getCoun_7(d in INTEGER)
    is
    a INTEGER;
begin
    select count(*) into a from employees WHERE employee_id=d;

end getCoun_7;
/

