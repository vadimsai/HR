create PROCEDURE getCoun_9(d in INTEGER, x out number)
    is
    a INTEGER;
begin
    select count(*) into x from employees WHERE employee_id=d;
    DBMS_OUTPUT.PUT_LINE(a);
end getCoun_9;
/

