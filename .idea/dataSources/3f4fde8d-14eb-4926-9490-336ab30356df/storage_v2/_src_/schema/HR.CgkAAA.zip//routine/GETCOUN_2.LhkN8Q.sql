create PROCEDURE getCoun_2(pOutParam out number)
    is
begin
    select count(*)
    into pOutParam
    from employees;
end getCoun_2;
/

